const CloseIcon = () => {
  return <div>hello</div>;
};

export default CloseIcon;
